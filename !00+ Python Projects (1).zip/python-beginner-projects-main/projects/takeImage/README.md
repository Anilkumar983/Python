This python script is used for taking images from your webcam and saving it on your local device. Path to the folder can be specified using the following command:

> python3 take_pictures_from_webcam.py --directory pathname

The default path would be your current directory.  

You can also give name to your image using following command:
> python3 take_pictures_from_webcam.py --name ImageName
