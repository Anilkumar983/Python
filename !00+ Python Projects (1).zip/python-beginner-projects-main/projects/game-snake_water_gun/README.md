# Sname Water and Gun

* GAME NAME - Snake, Water and Gun
* GAME RULES :
  1. You will have 3 chances (** you can make changes in no of chanches in the code.)
  2. Choose s for Snake, w for Water and g for Gun
  3. If any game draws, it'll be counted as 1 chance.
  4. If you pressed other than s, w and g key, it'll be counted as 1 chance.  

## Demo picture of the game:
![](https://user-images.githubusercontent.com/54176283/194770566-90d5507c-a1ef-4f6e-a691-c9143eb9966c.png)

## Setup
1. Python Should be installed in your system
2. Just download the game.py file and open it (bydefault it should be open in terminal).
* If you do not have or not want to install python in your system, you can download the game.exe file and directly run that executable file. 
