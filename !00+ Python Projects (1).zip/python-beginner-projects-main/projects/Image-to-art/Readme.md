# Image To ASCII ART Generator
<!--Remove the below lines and add yours -->
A simple Python Program to convert your images to ascii art.

### Prerequisites
<!--Remove the below lines and add yours -->
Make sure you have the latest version of Python, pip and Pillow installed on your PC.
Don't forget to save image to be coverted to ascii art in this directory as 'test1.jpg'.


### How to run the script
<!--Remove the below lines and add yours -->
Open and run this script easily with the Python IDLE or the command line by running the following command on this directory: python3 ascii_art.py.
