# Subnetting_FLSM

Subnetting_FLSM is developed for:
1.Calculation and analyzing number of hosts
2.Distribution hosts for each subnet by FLSM method
3.Transferring unique network address, broadcast address, usable hosts
