# Captcha Genrator 
A simple image captcha genrator

### Prerequisites
1. Install the dependencies by executing the following command 
   ```pip install -r requirements.txt```

2. Update the path of font in code (if required)
    ```image = ImageCaptcha(fonts=['<path>/ChelseaMarketsr.ttf', '<path>/DejaVuSanssr.ttf'])```

### Screenshot
![image](https://user-images.githubusercontent.com/39544459/137623915-1e837ada-f199-4513-a15d-ecbb969fd53e.png)

## *Mayur Singal*  
