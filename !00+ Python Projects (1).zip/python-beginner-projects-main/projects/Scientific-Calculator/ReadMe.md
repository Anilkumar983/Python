*This* **Scientific Calculator** *is a calculator designed to help you calculate science, engineering, and mathematics problems. It has way more buttons than your standard calculator that just lets you do your four basic arithmetic operations of addition, subtraction, multiplication, and division. This Scientific calculator is made with python which can be easily used by anyone.*
<br>
<br>
![image](https://user-images.githubusercontent.com/89387048/196713806-d9a3febc-5896-4ef7-a31d-373ee533347f.png)
